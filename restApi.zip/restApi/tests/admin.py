from django.contrib import admin
from tests.models import *
# Register your models here.

admin.site.register(CompanyDetails)
admin.site.register(KinawayData)
admin.site.register(BbfData)